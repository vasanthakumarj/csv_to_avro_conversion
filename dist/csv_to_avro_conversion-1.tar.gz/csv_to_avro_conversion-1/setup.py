from setuptools import setup, find_packages

setup(use_scm_version=True,
    # ...
    packages=['csv_to_avro_conversion']
    # ...
)
